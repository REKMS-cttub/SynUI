using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using SeliwareAPI;
using WebSocketSharp;
using WebSocketSharp.Server;

namespace SynapseUI
{
    public partial class MainForm : Form
    {
        private WebView2 _webView;
        private string _scriptsFolder;
        private bool _isMaximized = false;
        private Point _originalLocation;
        private Size _originalSize;
        private WebSocketServer _webSocketServer;
        private const int WEBSOCKET_PORT = 8765;
        
        // 设置相关
        private bool _autoInjectEnabled = false;
        private Thread _autoInjectThread;
        private bool _isRunning = true;
        private string _settingsPath;

        // 用于窗口拖动的 Win32 API
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);
        
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        
        public static void MoveWindow(IntPtr handle)
        {
            ReleaseCapture();
            SendMessage(handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        public MainForm()
        {
            Seliware.Initialize();
            InitializeComponent();
            InitializeWebSocketServer();
            InitializeAsync();
            InitializeWindow();
            InitializeSeliware();
            LoadSettings();
        }

        private void InitializeWebSocketServer()
        {
            _webSocketServer = new WebSocketServer(WEBSOCKET_PORT);
            _webSocketServer.AddWebSocketService<UIWebSocket>("/ui", () => new UIWebSocket(this));
            _webSocketServer.Start();
            Debug.WriteLine($"WebSocket server started on port {WEBSOCKET_PORT}");
        }

        private void InitializeWindow()
        {
            _originalLocation = this.Location;
            _originalSize = this.Size;
        }

        private async void InitializeAsync()
        {
            _webView = new WebView2();
            _webView.Dock = DockStyle.Fill;
            this.Controls.Add(_webView);
            
            var env = await CoreWebView2Environment.CreateAsync();
            await _webView.EnsureCoreWebView2Async(env);
            
            // 设置消息接收处理
            _webView.CoreWebView2.WebMessageReceived += WebView_WebMessageReceived;
            
            // 加载HTML文件
            string htmlPath = Path.Combine(Application.StartupPath, "core", "mainsite.html");
            if (File.Exists(htmlPath))
            {
                // 注入WebSocket连接脚本
                string webSocketScript = $@"<script>
                    const WS_PORT = {WEBSOCKET_PORT};
                    const socket = new WebSocket(`ws://localhost:${{WS_PORT}}/ui`);
                    
                    socket.addEventListener('open', (event) => {{
                        console.log('WebSocket connected');
                    }});
                    
                    socket.addEventListener('message', (event) => {{
                        const message = JSON.parse(event.data);
                        console.log('Received from server:', message);
                        handleWebViewMessage(message);
                    }});
                    
                    // 替换原来的postMessage
                    window.postMessageToServer = function(message) {{
                        console.log('Sending to server:', message);
                        socket.send(JSON.stringify(message));
                    }};
                </script>";
                
                string htmlContent = File.ReadAllText(htmlPath);
                htmlContent = htmlContent.Replace("</body>", $"{webSocketScript}</body>");
                _webView.CoreWebView2.NavigateToString(htmlContent);
            }
            else
            {
                MessageBox.Show("UI file not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 通过WebSocket发送消息到前端
        public void SendMessageToUI(object message)
        {
            if (_webSocketServer != null && _webSocketServer.IsListening)
            {
                _webSocketServer.WebSocketServices["/ui"].Sessions.Broadcast(JsonConvert.SerializeObject(message));
            }
        }

        private void InitializeSeliware()
        {
            try
            {
                // 设置脚本文件夹
                _scriptsFolder = Path.Combine(Application.StartupPath, "scripts");
                if (!Directory.Exists(_scriptsFolder))
                {
                    Directory.CreateDirectory(_scriptsFolder);
                }
                
                // 创建一些示例脚本
                CreateSampleScripts();
                
                // 发送初始文件列表
                SendScriptsList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to initialize: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CreateSampleScripts()
        {
            string[] sampleScripts = {
                "Aimbot.lua",
                "ESP.lua",
                "AutoFarm.lua",
                "Teleport.lua",
                "SpeedHack.lua",
                "PlayerFly.lua",
                "NoClip.lua",
                "AutoCollect.lua"
            };

            foreach (var script in sampleScripts)
            {
                string filePath = Path.Combine(_scriptsFolder, script);
                if (!File.Exists(filePath))
                {
                    File.WriteAllText(filePath, $"-- {script}\n-- Auto-generated sample script\n\nprint('Running {script}')\n");
                }
            }
        }

        private void WebView_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            // 保留此方法用于处理其他WebView2消息
            Debug.WriteLine($"WebView2 message: {e.WebMessageAsJson}");
        }

        public void HandleMessageFromUI(string messageJson)
        {
            try
            {
                var message = JsonConvert.DeserializeObject<Dictionary<string, object>>(messageJson);
                string type = message["type"].ToString();
                
                this.Invoke((MethodInvoker)delegate {
                    switch (type)
                    {
                        case "window_action":
                            HandleWindowAction(message["action"].ToString());
                            break;
                            
                        case "get_scripts_list":
                            SendScriptsList();
                            break;
                            
                        case "execute":
                            string code = message.ContainsKey("code") ? message["code"].ToString() : "";
                            string tabId = message.ContainsKey("tabId") ? message["tabId"].ToString() : "";
                            ExecuteCode(code, tabId);
                            break;
                            
                        case "open_file":
                            string openTabId = message.ContainsKey("tabId") ? message["tabId"].ToString() : "";
                            OpenFile(openTabId);
                            break;
                            
                        case "save_file":
                            string saveCode = message.ContainsKey("code") ? message["code"].ToString() : "";
                            string saveTabId = message.ContainsKey("tabId") ? message["tabId"].ToString() : "";
                            SaveFile(saveCode, saveTabId);
                            break;
                            
                        case "injectroblox":
                            InjectSeliware();
                            break;
                            
                        case "load_file":
                            string loadPath = message.ContainsKey("path") ? message["path"].ToString() : "";
                            string loadTabId = message.ContainsKey("tabId") ? message["tabId"].ToString() : "";
                            LoadFile(loadPath, loadTabId);
                            break;
                            
                        case "execute_file":
                            string executePath = message.ContainsKey("path") ? message["path"].ToString() : "";
                            ExecuteFile(executePath);
                            break;
                            
                        case "delete_file":
                            string deletePath = message.ContainsKey("path") ? message["path"].ToString() : "";
                            DeleteFile(deletePath);
                            break;

                        case "drag_window":
                            // 只在非最大化状态下允许拖动
                            if (!_isMaximized)
                            {
                                MoveWindow(this.Handle);
                            }
                            break;
                            
                        // 处理设置更改
                        case "set_topmost":
                            bool topmost = Convert.ToBoolean(message["value"]);
                            this.TopMost = topmost;
                            SaveSettings();
                            break;
                            
                        case "set_autoinject":
                            _autoInjectEnabled = Convert.ToBoolean(message["value"]);
                            SaveSettings();
                            
                            if (_autoInjectEnabled)
                            {
                                StartAutoInjectLoop();
                            }
                            else
                            {
                                StopAutoInjectLoop();
                            }
                            break;
                            
                        // 请求当前设置
                        case "get_settings":
                            SendCurrentSettings();
                            break;
                    }
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error handling message: {ex.Message}");
            }
        }

        private void HandleWindowAction(string action)
        {
            switch (action)
            {
                case "minimize":
                    this.WindowState = FormWindowState.Minimized;
                    break;
                    
                case "maximize":
                    ToggleMaximize();
                    break;
                    
                case "close":
                    this.Close();
                    break;
            }
        }

        private void ToggleMaximize()
        {
            if (_isMaximized)
            {
                this.Location = _originalLocation;
                this.Size = _originalSize;
                _isMaximized = false;
            }
            else
            {
                _originalLocation = this.Location;
                _originalSize = this.Size;
                this.Location = new Point(0, 0);
                this.Size = new Size(
                    Screen.PrimaryScreen.WorkingArea.Width,
                    Screen.PrimaryScreen.WorkingArea.Height
                );
                _isMaximized = true;
            }
        }

        private void SendScriptsList()
        {
            try
            {
                var files = new List<object>();
        
                // 添加文件夹
                var directories = Directory.GetDirectories(_scriptsFolder);
                foreach (var dir in directories)
                {
                    files.Add(new { 
                        name = Path.GetFileName(dir), 
                        path = dir.Replace("\\", "/"), // 统一使用正斜杠
                        type = "folder" 
                    });
                }
        
                // 添加文件
                var scriptFiles = Directory.GetFiles(_scriptsFolder, "*.lua");
                foreach (var file in scriptFiles)
                {
                    files.Add(new { 
                        name = Path.GetFileName(file), 
                        path = file.Replace("\\", "/"), // 统一使用正斜杠
                        type = "file" 
                    });
                }
        
                var message = new { 
                    type = "file_list", 
                    files = files 
                };
                
                SendMessageToUI(message);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error sending file list: {ex.Message}");
            }
        }

        private void ExecuteCode(string code, string tabId)
        {
            try
            {
                string processName = "robloxplayerbeta";
                Process[] processes = Process.GetProcessesByName(processName);
                if (processes.Length == 0)
                {
                    SendMessageToUI(new
                    {
                        type = "execute_result",
                        success = false,
                        reason = "not injected",
                        tabId = tabId
                    });
                    SendInjectionResult(false,"No roblox process found");
                    return;
                }
                if (Seliware.IsInjected() == false)
                {
                    SendMessageToUI(new
                    {
                        type = "execute_result",
                        success = false,
                        reason = "Not injected",
                        tabId = tabId
                    });

                    return;
                }
                

                // 在这里执行代码
                Debug.WriteLine($"Executing code in tab {tabId}:\n{code}");

                // 发送执行成功消息
                if (Seliware.IsInjected() == true)
                {
                    Seliware.Execute(code);
                    SendMessageToUI(new
                    {
                        type = "execute_result",
                        success = true,
                        tabId = tabId
                    });
                }
            }
            catch (Exception ex)
            {
                SendMessageToUI(new
                {
                    type = "execute_result",
                    success = false,
                    reason = ex.Message,
                    tabId = tabId
                });
            }
        }

        private void OpenFile(string tabId)
        {
            using (var dialog = new OpenFileDialog())
            {
                dialog.Filter = "Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";
                dialog.InitialDirectory = _scriptsFolder;
                
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    LoadFileToUI(dialog.FileName, tabId);
                }
            }
        }

        private void LoadFileToUI(string filePath, string tabId)
        {
            try
            {
                string content = File.ReadAllText(filePath);
                string fileName = Path.GetFileName(filePath);
        
                var message = new
                {
                    type = "file_loaded",
                    name = fileName,
                    content = content,
                    path = filePath.Replace("\\", "/"), // 统一使用正斜杠
                    tabId = tabId
                };
        
                SendMessageToUI(message);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading file: {ex.Message}");
            }
        }

        private void SaveFile(string content, string tabId)
        {
            if (string.IsNullOrEmpty(content))
            {
                MessageBox.Show("Editor content is empty!", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            using (var dialog = new SaveFileDialog())
            {
                dialog.Filter = "Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";
                dialog.InitialDirectory = _scriptsFolder;
                dialog.DefaultExt = "lua";
                
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllText(dialog.FileName, content);
                        
                        // 更新文件列表
                        SendScriptsList();
                        
                        // 更新标签标题
                        SendMessageToUI(new
                        {
                            type = "update_title",
                            title = Path.GetFileName(dialog.FileName),
                            path = dialog.FileName.Replace("\\", "/"), // 统一使用正斜杠
                            tabId = tabId
                        });
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error saving file: {ex.Message}", "Error", 
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void InjectSeliware()
        {
            Seliware.Inject();
            Seliware.Injected += delegate
            {
                SendInjectionResult(true,null);
            };
            
        }
        
        private void OnInjectionFailed(object sender, string error)
        {
            SendInjectionResult(false, error);
        }
        
        private void SendInjectionResult(bool success, string error)
        {
            this.Invoke((MethodInvoker)delegate {
                var message = new {
                    type = "inject_result",
                    success = success,
                    error = error
                };
                
                SendMessageToUI(message);
            });
        }

        private void LoadFile(string filePath, string tabId)
        {
            // 移除路径开头的斜杠
            string relativePath = filePath.TrimStart('/');
            string fullPath = Path.Combine(_scriptsFolder, relativePath);
            LoadFileToUI(fullPath, tabId);
        }

        private void ExecuteFile(string filePath)
        {
            try
            {
                if (Seliware.IsInjected() == false)
                {
                    MessageBox.Show("Please inject first!", "Error", 
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                
                
                // 移除路径开头的斜杠
                string relativePath = filePath.TrimStart('/');
                string fullPath = Path.Combine(_scriptsFolder, relativePath);
                
                string content = File.ReadAllText(fullPath);
                Seliware.Execute(content);
                
                // 在这里执行文件
                Debug.WriteLine($"Executing file: {fullPath}\n{content}");
                
                MessageBox.Show($"Executed file: {Path.GetFileName(fullPath)}", "Success", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error executing file: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteFile(string filePath)
        {
            try
            {
                // 移除路径开头的斜杠
                string relativePath = filePath.TrimStart('/');
                string fullPath = Path.Combine(_scriptsFolder, relativePath);
                
                if (File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                    SendScriptsList();
                    
                    MessageBox.Show($"Deleted file: {Path.GetFileName(fullPath)}", "Success", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting file: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        // 设置相关方法
        private void LoadSettings()
        {
            _settingsPath = Path.Combine(Application.UserAppDataPath, "synapse_settings.json");
            if (File.Exists(_settingsPath))
            {
                try
                {
                    string json = File.ReadAllText(_settingsPath);
                    var settings = JsonConvert.DeserializeObject<Dictionary<string, bool>>(json);
                    
                    if (settings.ContainsKey("TopMost"))
                        this.TopMost = settings["TopMost"];
                    
                    if (settings.ContainsKey("AutoInject"))
                    {
                        _autoInjectEnabled = settings["AutoInject"];
                        if (_autoInjectEnabled)
                        {
                            StartAutoInjectLoop();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error loading settings: {ex.Message}");
                }
            }
        }
        
        private void SaveSettings()
        {
            try
            {
                var settings = new Dictionary<string, bool>
                {
                    { "TopMost", this.TopMost },
                    { "AutoInject", _autoInjectEnabled }
                };
                
                string json = JsonConvert.SerializeObject(settings);
                File.WriteAllText(_settingsPath, json);
                Debug.WriteLine("Settings saved successfully");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error saving settings: {ex.Message}");
            }
        }
        
        private void StartAutoInjectLoop()
        {
            if (_autoInjectThread != null && _autoInjectThread.IsAlive)
                return;
        
            _isRunning = true;
    
            _autoInjectThread = new Thread(() => 
            {
                while (_isRunning && _autoInjectEnabled)
                {
                    try
                    {
                        // 检查Roblox进程是否存在且尚未注入
                        Process[] processes = Process.GetProcessesByName("RobloxPlayerBeta");
                        if (processes.Length > 0 && !Seliware.IsInjected())
                        {
                            // 注入
                            this.Invoke((MethodInvoker)delegate {
                                InjectSeliware();
                            });
                            
                            // 注入成功后停止循环
                            break;
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"AutoInject error: {ex.Message}");
                    }
            
                    // 每5秒检查一次
                    Thread.Sleep(5000);
                }
            });
    
            _autoInjectThread.IsBackground = true;
            _autoInjectThread.Start();
        }
        
        private void StopAutoInjectLoop()
        {
            _isRunning = false;
        }
        
        private void SendCurrentSettings()
        {
            var settings = new
            {
                type = "settings",
                topmost = this.TopMost,
                autoinject = _autoInjectEnabled
            };
            
            SendMessageToUI(settings);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            _isRunning = false;
            SaveSettings();
            
            if (_webSocketServer != null && _webSocketServer.IsListening)
            {
                _webSocketServer.Stop();
            }
        }
    }

    // WebSocket处理类
    public class UIWebSocket : WebSocketBehavior
    {
        private MainForm _mainForm;

        public UIWebSocket()
        {
            // 默认构造函数
        }

        public UIWebSocket(MainForm mainForm)
        {
            _mainForm = mainForm;
        }

        protected override void OnMessage(MessageEventArgs e)
        {
            if (_mainForm != null && e.IsText)
            {
                _mainForm.HandleMessageFromUI(e.Data);
            }
        }
    }
}